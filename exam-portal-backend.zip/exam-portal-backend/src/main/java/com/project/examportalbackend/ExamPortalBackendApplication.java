package com.project.examportalbackend;

import com.project.examportalbackend.models.Role;
import com.project.examportalbackend.models.User;
import com.project.examportalbackend.repository.RoleRepository;
import com.project.examportalbackend.repository.UserRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

@SpringBootApplication
public class ExamPortalBackendApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(ExamPortalBackendApplication.class, args);
	}

	@Bean
	public ApplicationRunner initializer(RoleRepository roleRepository) {
		return args -> roleRepository.saveAll(Arrays.asList(
				Role.builder().roleName("USER").roleDescription("Default Role provided to each user").build(),
				Role.builder().roleName("ADMIN").roleDescription("Superuser, who has access for all functionality").build()));
	}
	
	/*@Bean
	public CommandLineRunner demo(UserRepository userRepository) {
	    return (args) -> {
	    	User user = new User();
	    	Role role = roleRepository.findById("ADMIN").get();
	    	user.setFirstName("Rajesh");
	    	user.setLastName("Kumar");
	    	user.setUsername("rajesh@gmail.com");
	    	user.setPassword("12345");
	    	user.setPhoneNumber("9910178466");
	    	Set<Role> userRoles = new HashSet<>();
            userRoles.add(role);
            user.setRoles(userRoles);
            user.setPassword(passwordEncoder.encode(user.getPassword()));
            userRepository.save(user);
	    };
	}*/
}
